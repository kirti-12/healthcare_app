#! /bin/sh

git archive --format=zip --output=health_app.zip HEAD .
