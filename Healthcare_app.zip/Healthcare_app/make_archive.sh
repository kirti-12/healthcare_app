#! /bin/sh

git archive --format=zip --output=Healthcare_app.zip HEAD .
